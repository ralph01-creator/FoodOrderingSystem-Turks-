/*package com.restaurant;

import javax.swing.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        // Set up logging
        logger.info("Application starting...");

        try {
            // Show Splash Screen
            showSplashScreen();

            // Ensure GUI runs on the Event Dispatch Thread (EDT)
            SwingUtilities.invokeLater(() -> {
                try {
                    new OrderSystem(); // Launch the Ordering System GUI
                    logger.info("Order System launched successfully.");
                } catch (Exception e) {
                    logger.log(Level.SEVERE, "Error launching Order System", e);
                    JOptionPane.showMessageDialog(null, "Failed to start application!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });

        } catch (Exception e) {
            logger.log(Level.SEVERE, "Critical application failure", e);
            JOptionPane.showMessageDialog(null, "A critical error occurred!", "Fatal Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void showSplashScreen() {
        JWindow splash = new JWindow();
        JLabel splashLabel = new JLabel(new ImageIcon(Main.class.getResource("/images/splash.png")));
        splash.getContentPane().add(splashLabel, BorderLayout.CENTER);
        splash.setSize(400, 300);
        splash.setLocationRelativeTo(null);
        splash.setVisible(true);

        try {
            Thread.sleep(3000); // Show splash for 3 seconds
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        splash.setVisible(false);
        splash.dispose();
    }
}
*/

package com.restaurant;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new LoginSignup(); // Start with LoginSignup UI
            } catch (Exception e) {
                System.err.println("ayay nag error man: " + e.getMessage());
                                                                                }
                                                                                });
                                                                                }
                                                                                }

